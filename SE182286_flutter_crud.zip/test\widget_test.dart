import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:se182286_flutter_crud/main.dart';

void main() {
  testWidgets('Task screen renders', (WidgetTester tester) async {
    await tester.pumpWidget(const MyApp());

    expect(find.text('Task Manager'), findsOneWidget);
    expect(find.text('Enter task'), findsOneWidget);
  });
}
