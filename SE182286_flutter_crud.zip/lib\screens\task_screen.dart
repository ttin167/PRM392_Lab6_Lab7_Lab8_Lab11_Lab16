import 'package:flutter/material.dart';
import '../screens/edit_task_screen.dart';
import '../models/task.dart';
import '../repo/task_repository.dart';
import '../widgets/task_item.dart';

class TaskScreen extends StatefulWidget {
  const TaskScreen({super.key});

  @override
  State<TaskScreen> createState() => _TaskScreenState();
}

class _TaskScreenState extends State<TaskScreen> {
  final repo = TaskRepository();

  List<Task> tasks = [];

  final controller = TextEditingController();
  final searchController = TextEditingController();
  String searchQuery = '';

  @override
  void initState() {
    super.initState();
    loadTasks();
  }

  Future<void> loadTasks() async {
    final data = await repo.getTasks();

    setState(() {
      tasks = data;
    });
  }

  Future<void> addTask() async {
    final title = controller.text.trim();
    if (title.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter task title')),
      );
      return;
    }

    final isDuplicate = tasks.any(
      (task) => task.title.trim().toLowerCase() == title.toLowerCase(),
    );
    if (isDuplicate) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Task already exists')),
      );
      return;
    }

    await repo.insertTask(Task(title: title));

    controller.clear();
    searchController.clear();
    setState(() {
      searchQuery = '';
    });

    await loadTasks();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Task added')),
    );
  }

  Future<void> deleteTask(int id) async {
    await repo.deleteTask(id);

    loadTasks();
  }

  Future<void> confirmDelete(Task task) async {
    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Confirm delete'),
        content: Text('Delete task "${task.title}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (shouldDelete == true && task.id != null) {
      await deleteTask(task.id!);
    }
  }

  Future<void> editTask(Task task) async {
    final updatedTitle = await Navigator.push<String>(
      context,
      MaterialPageRoute(
        builder: (_) => EditTaskScreen(initialTitle: task.title),
      ),
    );

    if (updatedTitle == null) return;

    await repo.updateTask(Task(id: task.id, title: updatedTitle));
    loadTasks();
  }

  @override
  void dispose() {
    controller.dispose();
    searchController.dispose();
    super.dispose();
  }

  List<Task> get filteredTasks {
    final query = searchQuery.trim().toLowerCase();
    if (query.isEmpty) return tasks;
    return tasks
        .where((task) => task.title.toLowerCase().contains(query))
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Task Manager")),

      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(10),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: controller,
                    onSubmitted: (_) => addTask(),
                    decoration: const InputDecoration(hintText: "Enter task"),
                  ),
                ),

                IconButton(icon: const Icon(Icons.add), onPressed: addTask),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: TextField(
              controller: searchController,
              onChanged: (value) {
                setState(() {
                  searchQuery = value;
                });
              },
              decoration: const InputDecoration(
                hintText: "Search task",
                prefixIcon: Icon(Icons.search),
              ),
            ),
          ),
          const SizedBox(height: 8),

          Expanded(
            child: ListView.builder(
              itemCount: filteredTasks.length,
              itemBuilder: (context, index) {
                final task = filteredTasks[index];

                return TaskItem(
                  task: task,
                  onDelete: () => confirmDelete(task),
                  onEdit: () => editTask(task),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
