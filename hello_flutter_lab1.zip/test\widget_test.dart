// This is a basic Flutter widget test.
//
// To perform an interaction with a widget in your test, use the WidgetTester
// utility in the flutter_test package. For example, you can send tap and scroll
// gestures. You can also use WidgetTester to find child widgets in the widget
// tree, read text, and verify that the values of widget properties are correct.

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:hello_flutter_lab1/main.dart';

void main() {
  testWidgets('Lab 1 UI renders', (WidgetTester tester) async {
    await tester.pumpWidget(const MyApp());

    expect(find.text('Lab 1 Demo'), findsOneWidget);
    expect(find.text('Welcome to Flutter!'), findsOneWidget);
    expect(find.text('Your first customized layout 🙂'), findsOneWidget);
  });
}
