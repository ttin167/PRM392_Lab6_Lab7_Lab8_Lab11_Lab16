import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: CalculatorPage(),
    );
  }
}

class CalculatorPage extends StatefulWidget {
  const CalculatorPage({super.key});

  @override
  State<CalculatorPage> createState() => _CalculatorPageState();
}

class _CalculatorPageState extends State<CalculatorPage> {
  final TextEditingController number1Controller = TextEditingController();
  final TextEditingController number2Controller = TextEditingController();

  double? result;
  String? errorMessage;

  @override
  void dispose() {
    number1Controller.dispose();
    number2Controller.dispose();
    super.dispose();
  }

  void calculate(String operator) {
    final double? num1 = double.tryParse(number1Controller.text.trim());
    final double? num2 = double.tryParse(number2Controller.text.trim());

    if (num1 == null || num2 == null) {
      setState(() {
        result = null;
        errorMessage = 'Please enter valid numbers.';
      });
      return;
    }

    if (operator == '/' && num2 == 0) {
      setState(() {
        result = null;
        errorMessage = 'Cannot divide by zero.';
      });
      return;
    }

    setState(() {
      errorMessage = null;
      if (operator == '+') {
        result = num1 + num2;
      } else if (operator == '-') {
        result = num1 - num2;
      } else if (operator == '*') {
        result = num1 * num2;
      } else if (operator == '/') {
        result = num1 / num2;
      }
    });
  }

  Widget _buildFirstInput() {
    return TextField(
      controller: number1Controller,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      decoration: const InputDecoration(
        labelText: 'Enter first number',
        border: OutlineInputBorder(),
      ),
    );
  }

  Widget _buildSecondInput() {
    return TextField(
      controller: number2Controller,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      decoration: const InputDecoration(
        labelText: 'Enter second number',
        border: OutlineInputBorder(),
      ),
    );
  }

  Widget _buildOperatorButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _buildButton('+'),
        _buildButton('-'),
        _buildButton('*'),
        _buildButton('/'),
      ],
    );
  }

  Widget _buildButton(String operator) {
    return ElevatedButton(
      onPressed: () => calculate(operator),
      child: Text(operator),
    );
  }

  Widget _buildClearButton() {
    return OutlinedButton(
      onPressed: () {
        setState(() {
          number1Controller.clear();
          number2Controller.clear();
          result = null;
          errorMessage = null;
        });
      },
      child: const Text('Clear'),
    );
  }

  Widget _buildResult() {
    final String text;
    if (errorMessage != null) {
      text = errorMessage!;
    } else if (result != null) {
      text = 'Result: ${_formatResult(result!)}';
    } else {
      text = 'Result: --';
    }

    return Text(
      text,
      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
    );
  }

  String _formatResult(double value) {
    if (value == value.roundToDouble()) {
      return value.toInt().toString();
    }
    return value.toStringAsFixed(2);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Simple Calculator')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            _buildFirstInput(),
            const SizedBox(height: 16),
            _buildSecondInput(),
            const SizedBox(height: 20),
            _buildOperatorButtons(),
            const SizedBox(height: 12),
            _buildClearButton(),
            const SizedBox(height: 30),
            _buildResult(),
          ],
        ),
      ),
    );
  }
}
